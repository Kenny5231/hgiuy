/*
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sosag
 */
/*
public class MetodoDatos {
    private String Username;
    public boolean activar;
    static ArrayList <User>Usuarios=new ArrayList<>();
    String Userloged;
    
    public String logs="";
    
    public (){
        
    }
            
}
*/