
import javax.swing.ImageIcon;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kenny
 */
public class Almacen_datos {
    private static boolean colocado1=false;
    private static boolean colocado2=false;
    private static boolean turno1=true;
    private static boolean turno2=false;
    private static String dificultad ="Easy" ;
    private static String modo="Tutorial";
    private static String estado;
    private static boolean winner;
    private static String Player1;
    private static String Player2;
    private int vidaporta;
    private int vidaacorazado;
    private int vidasubmarino;
    private int vida_destrutor;

    public static String getPlayer1() {
        return Player1;
    }

    public static void setPlayer1(String Player1) {
        System.out.println("jugador 1: "+Player1);
        Almacen_datos.Player1 = Player1;
    }

    public static String getPlayer2() {
        return Player2;
    }

    public static void setPlayer2(String Player2) {
        System.out.println("jugador2: "+Player2 );
        Almacen_datos.Player2 = Player2;
    }

    public static boolean isWinner() {
        return winner;
    }

    public static void setWinner(boolean winner) {
        System.out.println("setwinner: "+winner);
        Almacen_datos.winner = winner;
    }

    
    
    public static boolean isColocado1() {
        return colocado1;
    }

    public static void setColocado1(boolean colocado1) {
        System.out.println("colocado1: "+colocado1);
        Almacen_datos.colocado1 = colocado1;
    }

    public static boolean isColocado2() {
        return colocado2;
    }

    public static void setColocado2(boolean colocado2) {
        System.out.println("colocado2: "+colocado2);
        Almacen_datos.colocado2 = colocado2;
    }
    
    
    
    
    
    
    public static boolean isTurno1() {
        return turno1;
    }

    public static void setTurno1(boolean turno1) {
        System.out.println("turno1: "+turno1);
        Almacen_datos.turno1 = turno1;
    }

    public static boolean isTurno2() {
        return turno2;
    }

    public static void setTurno2(boolean turno2) {
                System.out.println("turno2: "+turno2);
        Almacen_datos.turno2 = turno2;
    }
    
    
    
    
    //configuracion de barcos y modos 
     public int  portaavione(){
     vidaporta=5;
    return vidaporta;
    }
    public int acorazado(){
    vidaacorazado=4;
    return vidaacorazado;
    }
    public int submarino(){
    vidasubmarino=3;
    return vidasubmarino;
    }
    public int destructor(){
    vida_destrutor=2;
    return vida_destrutor;
    }
    
    //descuento vida por vez acertada 
    public void  atacporta(){
    vidaporta--;    
    }
    public void atacacorazado(){
    vidaacorazado--;
    }
    public void atacsubmarino(){
    vidasubmarino--;
    }
    public void atacdestrutor(){
    vida_destrutor--;
    }
    
    //llamado y envio del modo de juego
    public static String getModo() {
        return modo;
    }

    public static void setModo(String mod) {
        modo = mod;
        System.out.println(modo);
    }
    //llamado y enviado de dificultad
    public static String getDificultad() {
        return dificultad;
    }

    public static void setDificultad(String dificult) {
        dificultad = dificult;
        System.out.println(dificultad);
    }

    
    
    
    
    
    
    
 
    
    
    
}
