
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author Kenny
 */
/*
public class Registros {

    int tamano;

    Usuarios[] hola;
     
    public Registros() {
        tamano = 0;
        hola = new Usuarios[100];
    }

    public boolean AgregarPersona(String nombre, String Password) {
        if (buscar(nombre) == null) {
            hola[tamano] = new Usuarios(nombre, Password);
            tamano++;
            return true;
        }      
        return false;
    }

    public Usuarios buscar(String nombre) {
        for (int i = 0; i < tamano; i++) {
            if (hola[i] != null && hola[i].getUsuarios().equals(nombre)) {
                return hola[i];
            }
        }
        return null;
    }

    public Usuarios buscarcontra(String Password) {
        for (int i = 0; i < tamano; i++) {
            if (hola[i] != null && hola[i].getcontra().equals(Password)) {
                return hola[i];
            }
        }
        return null;
    }
}

*/