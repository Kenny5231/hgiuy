/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kenny
 */
public class Usuarios {

    String Nombre,Contra;

    public Usuarios(String nombre, String contra) {
        //variables 
        Nombre=nombre;   
    
        Contra=contra;

    }

    public String getcontra(){
    return this.Contra;
   
    }    
    public void setcontra(String contra){   
    this.Contra=contra;
    }  
 
    public void setnombre(String nombreingresado){


     this.Contra=nombreingresado; 


    }    

    public String getnombre(){



    return this.Contra;    

    }   
    
    
    
    
}
